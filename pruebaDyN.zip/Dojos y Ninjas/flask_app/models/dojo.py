from flask_app.config.mysqlconnection import connectToMySQL


class dojo():
    def __init__(self,data):
        self.id=data["id"]
        self.nombre=data["nombre"]
        self.created_at=data["created_at"]
        self.updated_at=data["updated_at"]

@classmethod
def create(cls,data):
    query = "INSERT INTO dojos (nombre) VALUES (%(nombre)s);"
    return connectToMySQL ('odami').query_db(query,data)

@classmethod
def create(cls):
    query = "SELECT * from dojos;"
    return connectToMySQL ('odami').query_db(query)

@classmethod
def create(cls,data):
    query = "SELECT * from dojos WHERE id = %(id)s;"
    return connectToMySQL ('odami').query_db(query,data)

@classmethod
def create(cls,data):
    query = "UPDATE dojos SET nombre = %(nombre)s WHERE (id = %(id)s);"
    return connectToMySQL ('odami').query_db(query,data)