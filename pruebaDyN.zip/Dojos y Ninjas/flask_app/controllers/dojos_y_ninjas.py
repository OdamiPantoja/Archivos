# dojos_y_ninjas.py
from flask_app import app
from flask import render_template,redirect,request,session,flash
from dojos_y_ninjas import dojos_y_ninjas
