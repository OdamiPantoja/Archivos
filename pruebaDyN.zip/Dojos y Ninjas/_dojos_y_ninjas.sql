INSERT INTO dojos ( nombre )
VALUES ('Chile'),
    ('Usa'),
    ('Mexico');

SELECT *
FROM dojos;

DELETE FROM dojos
WHERE id = 1;

DELETE FROM dojos
WHERE id = 2;

DELETE FROM dojos
WHERE id = 3;

INSERT INTO ninjas ( nombre, apellido, edad, dojo_id )
VALUES ( 'Alex', 'Miller', 25, 4),
		( 'Martha', 'Gonzalez', 23, 4),
        ('Roger', 'Infante', 18, 4);
SELECT *
FROM ninjas;

INSERT INTO ninjas ( nombre, apellido, edad, dojo_id )
VALUES ( 'Miguel', 'Gonzalez', 27, 5),
		( 'Ana', 'Morales', 23, 5),
        ('Alan', 'Infante', 19, 5);
SELECT *
FROM ninjas;

INSERT INTO ninjas ( nombre, apellido, edad, dojo_id )
VALUES ( 'Brianna', 'Winston', 24, 6),
		( 'Julieta', 'Rodriguez', 19, 6),
        ('Marcela', 'Torres', 29, 6);
SELECT *
FROM ninjas;

SELECT *
FROM ninjas
WHERE dojo_id = 4;

SELECT *
FROM ninjas
WHERE dojo_id = 6;


SELECT dojos.nombre
FROM ninjas JOIN dojos
	ON ninjas.dojo_id = dojos.id
WHERE ninjas.id = 9;