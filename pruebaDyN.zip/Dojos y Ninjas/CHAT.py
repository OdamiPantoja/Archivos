from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="tu_usuario",
    password="tu_contraseña",
    database="tu_base_de_datos"
)

cursor = db.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS dojos (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(255))")
cursor.execute("CREATE TABLE IF NOT EXISTS ninjas (id INT AUTO_INCREMENT PRIMARY KEY, nombre VARCHAR(255), apellido VARCHAR(255), edad INT, dojo_id INT, FOREIGN KEY (dojo_id) REFERENCES dojos(id))")


@app.route('/dojos', methods=['GET', 'POST'])
def dojos():
    if request.method == 'POST':
        nombre = request.form['nombre']
        cursor = db.cursor()
        cursor.execute("INSERT INTO dojos (nombre) VALUES (%s)", (nombre,))
        db.commit()

    cursor = db.cursor()
    cursor.execute("SELECT * FROM dojos")
    dojos = cursor.fetchall()
    return render_template('dojos.html', dojos=dojos)


@app.route('/dojo/<int:dojo_id>', methods=['GET', 'POST'])
def dojo_show(dojo_id):
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        edad = int(request.form['edad'])
        cursor = db.cursor()
        cursor.execute("INSERT INTO ninjas (nombre, apellido, edad, dojo_id) VALUES (%s, %s, %s, %s)", (nombre, apellido, edad, dojo_id))
        db.commit()

    cursor = db.cursor()
    cursor.execute("SELECT * FROM ninjas WHERE dojo_id = %s", (dojo_id,))
    ninjas = cursor.fetchall()
    return render_template('dojo_show.html', dojo_id=dojo_id, ninjas=ninjas)


@app.route('/ninja', methods=['GET', 'POST'])
def ninja():
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        edad = int(request.form['edad'])
        dojo_id = int(request.form['dojo'])
        cursor = db.cursor()
        cursor.execute("INSERT INTO ninjas (nombre, apellido, edad, dojo_id) VALUES (%s, %s, %s, %s)", (nombre, apellido, edad, dojo_id))
        db.commit()
        return redirect('/dojo/{}'.format(dojo_id))

    cursor = db.cursor()
    cursor.execute("SELECT * FROM dojos")
    dojos = cursor.fetchall()
    return render_template('ninja.html', dojos=dojos)


@app.route('/')
def index():
    return redirect('/dojos')

if __name__ == '__main__':
    app.run(debug=True, port = 5001)