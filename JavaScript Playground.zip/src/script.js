let odami = ('hello')
console.log(odami)