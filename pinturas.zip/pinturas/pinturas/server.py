from app_pintura import app
from app_pintura.controladores import controlador_usuario, controlador_pintura

if __name__ == '__main__':
    app.run(debug = True, port =5000)